
#include <cstdio>

int main(int argc, char** argv) {

  int myArray[10];

  printf("%x\t%x\n", myArray[-8], myArray[10]);
 
}
