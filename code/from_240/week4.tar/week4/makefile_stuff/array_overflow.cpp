
#include <cstdio>

int main(int argc, char** argv) {

  int myarray[10];

  printf("%x\t%x\n", myarray[-8], myarray[10]);

}






