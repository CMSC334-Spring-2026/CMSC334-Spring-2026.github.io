
int main() {


  int myint{5};

  myint = 7;

}

