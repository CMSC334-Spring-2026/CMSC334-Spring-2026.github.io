
#include <iostream>

using namespace std;

int main() {

  exit(1);


}
