#include <iostream>

using namespace std;

void foo(char a, int size, int b, int c) {

  char myArray[size];

  for (int i = 0; i < size; ++i) {
    myArray[size] = a;
  }

  // So that the compiler doesn't warn me that I
  // have unused variables
  ++b;
  ++c; 

}



int main() {

  cout << "Entering foo" << endl;
  
  foo('A', 10, 1,2);

  cout << "foo has ended" << endl;
  return 0;

}















