
#include <iostream>

using namespace std;

int main() {

  int count{4};
  cout << "Hello World!" << endl;
  return 0;

}


  
