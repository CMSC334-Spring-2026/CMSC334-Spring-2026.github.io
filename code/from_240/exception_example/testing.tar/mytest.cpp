#include <iostream>
using namespace std;

int main()
{
    char* c = 0;
    string s = c;
//    cout << s << endl;
    return 0;
}
